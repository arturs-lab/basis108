This is PS/2 to Basis 108 keyboard converter made from PS/2 to 
Apple II converter by S. Kienzl 
(http://knzl.de/ps2-keyboard-for-apple-ii/).

The following changes have been made:
 - STROBE signal is inverted
 - Keymap covers all 7-bit ASCII
 - Caps-lock implemented as Shift-lock
 - Legacy headers defined.
I have no idea how, but this code is not compiling in my 
home set-up, when the same Hi-tech C 9.83 in university 
compiles it well.
To deal with this problem, HEX file is supplied.

2013 MCbx