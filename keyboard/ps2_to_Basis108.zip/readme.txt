PS/2-Keyboard to Apple II-converter
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

The webpage with all the information is at
http://seb.riot.org/appleII/keyboard.sml
.


Files:
~~~~~

ps2_to_apple2_SVN??_16F676.hex
ps2_to_apple2_SVN??_16F630_not_tested.hex 

 These are the files to flash on the PIC. I have used a 16F676 myself,
 but since it's almost the same as a 16F630 (except for the A/D, which
 is disabled in the 16F676-build) I expect it to work --
 I haven't tested it though.


ps2_to_apple2_SVN??/
 
  Source-code and Microchip MPLAB project-files.
  I used the following stuff (all downloadable for free) to compile it:
    * MPLAB IDE 7.62
    * HI-TECH PICC STD v9.60PL2
    * HI-TECH MPLAB-Integration (http://microchip.htsoft.com/support/mplab_for_version_8_compilers.php)


schematics_rev?.png

  Schematics
