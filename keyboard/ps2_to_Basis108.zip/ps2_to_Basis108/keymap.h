#ifndef KEYMAP_H
#define KEYMAP_H

extern const unsigned char keymap[];
extern const unsigned char keymap_size;
extern const unsigned char keymap_shift[];
extern const unsigned char keymap_shift_size;
extern const unsigned char keymap_ctrl[];
extern const unsigned char keymap_ctrl_size;

#endif
