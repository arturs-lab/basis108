#!/bin/bash

# use to copy'n'paste into sbs-file
# parity isn't calculated+used  

# bittrain for "="
#bittrain="0 1 0 1 0 1 0 1 0 0 1"

# two "=" after each other
bittrain="P P 0 1 0 1 0 1 0 1 0 0 1 P 0 1 0 1 0 1 0 1 0 0 1"

startc=0
ptime=30

for b in $bittrain; do

	if [ $b = "P" ]; then
		let startc=startc+5000
		continue
	fi
	
	echo --
	echo $startc
	echo 0
	echo $b
	echo --
	let startc=startc+ptime
	echo $startc
	echo 1
	echo
	let startc=startc+ptime
done
