The six binary files in this zip file recreate "double-decker" firmware ROMs or EPROMs for the Basis 108.   

The six 24-pin sockets near the front of the motherboard originally held a single 2716 (2K) eprom in the "D0" position. This provided the ability to boot a floppy drive, or enter the Basis version of the Apple "monitor" with the classic Apple "CALL -151" command.  There was no BASIC interpreter on board.  

You can replace this with the full set of either six standard (2K) 2716 Apple ][ ROMs allowing boot to a standard Applesoft BASIC prompt, or boot the usual Apple 5 1/4" floppy drive connected to slot 6.   Or you could install six EPROMs containing the enhanced Basis version of the monitor ROM & the enhanced Basis version of Applesoft BASIC called "FP80" (Floating Point 80-Cols).  

Or, if you are a truly hard-core historic hardware enthusiast, the "Integer Basic" ROMs of the original (non-Plus) Apple ][.

The Apple firmware is far more compatible with software for the Apple ][ and ][+ .  The Basis firmware allows access to enhanced features such as the built-in serial port, full upper/lower case entry & display, built-in 80-column display without an add-on card, and access to the function keys on the Basis keyboard from BASIC programs. 

FP80 added keywords to Applesoft BASIC.  The command "FP80" activates the 80-column display mode.  "FP40 returns to the classic Apple ][ 40-column mode, but with full upper/lower case display.  "PR#9" accesses the built-in clone of an Apple "Super Serial Card".    



The six 24-pin sockets are actually pinned out for (4K) 2732 ROMs/EPROMs. The most-significant-bit address line of a 2732 is brought out to the 6-pin header "J10", just to the right of the sockets. The 2x3 six-pin header has .1-inch spacing and mates with a Molex "KK" series connector. By connecting a single-pole double-throw toggle switch to this header, you can select either the lower half or the upper half of 2732 eproms. I.e. you can have the equivalent of two sets of 2716s in the same sockets at once, and select one or the other at will. 
   

The 2732 ROM-image files in this archive contain BOTH the classic Apple ][+ firmware -AND- the enhanced Basis version.  Just power-off, flip the toggle switch and power back on to switch modes.  

The files are straight binary images of the ROMs (not Intel hex files) that nearly any EPROM programmer can read.   Use any flavor of 2732 (2732, 2732A, 27C32, etc) with an access speed of 200 nS or better.  Note that the different flavors require different PROGRAMMING voltages, normally selected by an eprom type menu in the programming software.    Once programmed, all of them are READ during operation with the same voltages and are essentially identical. 

Since these ROMs are never going to be erased and re-written again once programmed, you might want to use the less-expensive one-time-use equivalent of the 2732.   These single-use eproms are encased in plastic instead of ceramic, and don't have the erase windows.

The photos in this archivew show the eprom socket sequence and the switch connection point.


edacs800      15 March 2019

